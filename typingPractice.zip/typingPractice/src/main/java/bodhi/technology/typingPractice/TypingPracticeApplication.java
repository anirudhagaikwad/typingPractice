package bodhi.technology.typingPractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TypingPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(TypingPracticeApplication.class, args);
	}

}
